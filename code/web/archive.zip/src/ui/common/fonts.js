// Fonts

export const primary = `'Roboto', sans-serif`

export const secondary = `'Lobster', cursive`